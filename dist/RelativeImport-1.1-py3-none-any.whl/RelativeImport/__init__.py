

from .RelativeImport import RelativeImport as RImport#用的时候嫌烦，改名为RImport

__all__ = ['RImport']

